# Power BI Build Notes — Walmart Store Performance Analysis

## 1. Load the data
Import both CSVs (Get Data → Text/CSV): `data/walmart_sales.csv` and `data/store_info.csv`.

## 2. Data model
- Relate `walmart_sales[store_id]` → `store_info[store_id]` (many-to-one).
- Add a Date table and relate to `walmart_sales[date]`:
```DAX
DateTable = CALENDAR(MIN(walmart_sales[date]), MAX(walmart_sales[date]))
```
Mark `DateTable` as a Date Table (Modeling → Mark as Date Table).

## 3. Core DAX measures

```DAX
Total Sales = SUM(walmart_sales[weekly_sales])

Avg Daily Sales = AVERAGE(walmart_sales[weekly_sales])

Store Count = DISTINCTCOUNT(walmart_sales[store_id])

Holiday Avg Sales =
CALCULATE([Avg Daily Sales], walmart_sales[is_holiday] = 1)

Non-Holiday Avg Sales =
CALCULATE([Avg Daily Sales], walmart_sales[is_holiday] = 0)

Holiday Sales Lift % =
DIVIDE([Holiday Avg Sales] - [Non-Holiday Avg Sales], [Non-Holiday Avg Sales], 0)

Total Markdown Spend = SUM(walmart_sales[markdown])

Sales MoM Growth % =
VAR CurrMonth = [Total Sales]
VAR PrevMonth = CALCULATE([Total Sales], DATEADD(DateTable[Date], -1, MONTH))
RETURN DIVIDE(CurrMonth - PrevMonth, PrevMonth, 0)

Cumulative Sales (YTD) =
TOTALYTD([Total Sales], DateTable[Date])

Top Store Rank =
RANKX(ALL(store_info[store_id]), [Total Sales], , DESC)

Store Rank Within Region =
RANKX(
    FILTER(ALL(store_info), store_info[region] = MAX(store_info[region])),
    CALCULATE([Total Sales]),
    ,
    DESC
)
```

## 4. Suggested dashboard pages
- **Overview**: KPI cards (Total Sales, Avg Daily Sales, Store Count, Holiday Sales Lift %),
  cumulative sales trend line by month.
- **Seasonality**: Average sales by month (line chart), holiday vs non-holiday comparison
  (clustered bar).
- **Store & Region Performance**: Ranked bar chart of stores by total sales, region
  comparison map/bar chart, top store per region table.
- **Markdown Analysis**: Markdown spend vs sales lift, filterable by store/region.

## 5. Filters/Slicers
Slicers for `region`, `store_type`, `is_holiday`, and a date range slicer on `date`.
